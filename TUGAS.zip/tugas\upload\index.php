<?php
include 'koneksi.php';
?>

<!DOCTYPE html>
<html>
<head>
    <title>Data Mahasiswa</title>
</head>
<body>
<h2>Data Mahasiswa</h2>
<a href="tambah.php">Tambah Data</a><br><br>

<table border="1" cellpadding="5" cellspacing="0">
<tr>
    <th>NIM</th>
    <th>Nama</th>
    <th>Prodi</th>
    <th>Alamat</th>
    <th>Foto</th>
    <th>Aksi</th>
</tr>
<?php
$result = $conn->query("SELECT * FROM mahasiswa");
if($result){
    while($row = $result->fetch_assoc()):
?>
<tr>
    <td><?php echo $row['nim']; ?></td>
    <td><?php echo $row['nama']; ?></td>
    <td><?php echo $row['prodi']; ?></td>
    <td><?php echo $row['alamat']; ?></td>
    <td>
        <?php if($row['gambar'] != '' && file_exists($row['gambar'])): ?>
            <img src="<?php echo $row['gambar']; ?>" width="80">
        <?php else: ?>
            -
        <?php endif; ?>
    </td>
    <td>
        <a href="edit.php?nim=<?php echo $row['nim']; ?>">Edit</a> |
        <a href="hapus.php?nim=<?php echo $row['nim']; ?>" onclick="return confirm('Hapus data?')">Hapus</a>
    </td>
</tr>
<?php endwhile; } ?>
</table>
</body>
</html>
