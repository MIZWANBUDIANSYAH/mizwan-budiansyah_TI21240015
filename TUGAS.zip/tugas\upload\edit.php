<?php
include 'koneksi.php';

if(!isset($_GET['nim'])){
    header("Location: index.php");
    exit;
}

$nim = (int)$_GET['nim'];
$result = $conn->query("SELECT * FROM mahasiswa WHERE nim=$nim");
if(!$result || $result->num_rows == 0){
    echo "Data mahasiswa tidak ditemukan!";
    exit;
}
$data = $result->fetch_assoc();

if(isset($_POST['update'])){
    $nama = $_POST['nama'];
    $prodi = $_POST['prodi'];
    $alamat = $_POST['alamat'];

    if(isset($_FILES['gambar']) && $_FILES['gambar']['name'] != ''){
        $foto = "uploads/".basename($_FILES['gambar']['name']);
        if(move_uploaded_file($_FILES['gambar']['tmp_name'], $foto)){
            if(!empty($data['gambar']) && file_exists($data['gambar'])){
                unlink($data['gambar']);
            }
            $sql = "UPDATE mahasiswa SET nama='$nama', prodi='$prodi', alamat='$alamat', gambar='$foto' WHERE nim=$nim";
        } else {
            echo "Gagal upload foto!";
            $sql = "UPDATE mahasiswa SET nama='$nama', prodi='$prodi', alamat='$alamat' WHERE nim=$nim";
        }
    } else {
        $sql = "UPDATE mahasiswa SET nama='$nama', prodi='$prodi', alamat='$alamat' WHERE nim=$nim";
    }

    if($conn->query($sql)){
        header("Location: index.php");
        exit;
    } else {
        echo "Error update: " . $conn->error;
    }
}
?>

<h2>Edit Data Mahasiswa</h2>
<form method="post" enctype="multipart/form-data">
    Nama: <input type="text" name="nama" value="<?php echo htmlspecialchars($data['nama']); ?>" required><br>
    Prodi: <input type="text" name="prodi" value="<?php echo htmlspecialchars($data['prodi']); ?>" required><br>
    Alamat: <input type="text" name="alamat" value="<?php echo htmlspecialchars($data['alamat']); ?>" required><br>
    Foto: <input type="file" name="gambar"><br>
    <?php if(!empty($data['gambar']) && file_exists($data['gambar'])): ?>
        <img src="<?php echo $data['gambar']; ?>" width="80"><br>
    <?php endif; ?>
    <button type="submit" name="update">Update</button>
</form>
<a href="index.php">Kembali</a>
