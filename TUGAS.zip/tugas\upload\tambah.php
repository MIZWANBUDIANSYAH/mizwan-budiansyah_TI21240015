<?php
include 'koneksi.php';

if(isset($_POST['submit'])){
    $nama = $_POST['nama'];
    $prodi = $_POST['prodi'];
    $alamat = $_POST['alamat'];

    $foto = '';
    if(isset($_FILES['gambar']) && $_FILES['gambar']['name'] != ''){
        $foto = "uploads/".basename($_FILES['gambar']['name']);
        move_uploaded_file($_FILES['gambar']['tmp_name'], $foto);
    }

    $sql = "INSERT INTO mahasiswa (nama, prodi, alamat, gambar) VALUES ('$nama','$prodi','$alamat','$foto')";
    if($conn->query($sql)){
        header("Location: index.php");
    } else {
        echo "Error: ".$conn->error;
    }
}
?>

<h2>Tambah Data Mahasiswa</h2>
<form method="post" enctype="multipart/form-data">
    Nama: <input type="text" name="nama" required><br>
    Prodi: <input type="text" name="prodi" required><br>
    Alamat: <input type="text" name="alamat" required><br>
    Foto: <input type="file" name="gambar"><br>
    <button type="submit" name="submit">Tambah</button>
</form>
<a href="index.php">Kembali</a>
