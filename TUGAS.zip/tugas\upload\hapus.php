<?php
include 'koneksi.php';

if(isset($_GET['nim'])){
    $nim = (int)$_GET['nim'];
    $data = $conn->query("SELECT gambar FROM mahasiswa WHERE nim=$nim")->fetch_assoc();
    if(!empty($data['gambar']) && file_exists($data['gambar'])){
        unlink($data['gambar']);
    }
    $conn->query("DELETE FROM mahasiswa WHERE nim=$nim");
}

header("Location: index.php");
